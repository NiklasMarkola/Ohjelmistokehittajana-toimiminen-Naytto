namespace Unity.VisualScripting
{
    public class MacroDescription : Description, IMacroDescription { }
}
