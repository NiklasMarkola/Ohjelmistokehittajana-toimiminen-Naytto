using System;

namespace Unity.VisualScripting
{
    public class WindowClose : Exception
    {
        public WindowClose() { }
    }
}
