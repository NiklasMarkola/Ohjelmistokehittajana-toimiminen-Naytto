namespace Unity.VisualScripting
{
    public interface IGraphDescription : IDescription { }
}
