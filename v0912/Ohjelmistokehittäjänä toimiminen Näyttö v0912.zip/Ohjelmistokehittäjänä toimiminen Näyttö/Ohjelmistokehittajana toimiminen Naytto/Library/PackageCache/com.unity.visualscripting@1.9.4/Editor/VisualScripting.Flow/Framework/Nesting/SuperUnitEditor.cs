namespace Unity.VisualScripting
{
    [Editor(typeof(SubgraphUnit))]
    public sealed class SuperUnitEditor : NesterUnitEditor
    {
        public SuperUnitEditor(Metadata metadata) : base(metadata) { }
    }
}
