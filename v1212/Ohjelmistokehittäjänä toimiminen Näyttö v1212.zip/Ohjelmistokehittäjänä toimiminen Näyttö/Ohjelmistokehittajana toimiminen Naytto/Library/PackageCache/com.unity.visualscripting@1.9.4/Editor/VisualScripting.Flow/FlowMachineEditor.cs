namespace Unity.VisualScripting
{
    [Editor(typeof(ScriptMachine))]
    public class FlowMachineEditor : MachineEditor
    {
        public FlowMachineEditor(Metadata metadata) : base(metadata) { }
    }
}
